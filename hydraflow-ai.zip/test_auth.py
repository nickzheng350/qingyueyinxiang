#!/usr/bin/env python3
"""用户认证测试脚本"""

import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.auth import get_auth_manager


def test_auth():
    """测试认证功能"""
    print("=" * 60)
    print("用户认证功能测试")
    print("=" * 60)
    print()
    
    # 1. 获取认证管理器
    print("1. 获取认证管理器...")
    auth = get_auth_manager()
    print("   ✓ 认证管理器已准备")
    print()
    
    # 2. 测试默认管理员用户
    print("2. 测试默认管理员登录...")
    token = auth.authenticate("admin", "")  # 默认管理员无密码
    print(f"   登录结果: {'成功' if token else '失败'}")
    if token:
        print(f"   Token: {token[:20]}...")
    print()
    
    # 3. 创建测试用户
    print("3. 创建测试用户...")
    user = auth.create_user(
        username="testuser",
        password="testpass123",
        email="test@example.com",
        role="user"
    )
    print(f"   创建结果: {'成功' if user else '失败'}")
    if user:
        print(f"   用户ID: {user.id}")
        print(f"   用户名: {user.username}")
        print(f"   邮箱: {user.email}")
        print(f"   角色: {user.role}")
    print()
    
    # 4. 测试用户登录
    print("4. 测试用户登录...")
    token = auth.authenticate("testuser", "testpass123")
    print(f"   登录结果: {'成功' if token else '失败'}")
    if token:
        print(f"   Token: {token[:20]}...")
        # 验证令牌
        username = auth.verify_token(token)
        print(f"   Token验证: {'有效' if username else '无效'}")
        print(f"   用户名: {username}")
    print()
    
    # 5. 测试密码错误
    print("5. 测试密码错误...")
    token = auth.authenticate("testuser", "wrongpass")
    print(f"   登录结果: {'成功' if token else '失败(预期)'}")
    print()
    
    # 6. 测试令牌过期/注销
    print("6. 测试登出...")
    token = auth.authenticate("testuser", "testpass123")
    if token:
        result = auth.logout(token)
        print(f"   登出结果: {'成功' if result else '失败'}")
        # 验证令牌已失效
        username = auth.verify_token(token)
        print(f"   Token验证(登出后): {'有效' if username else '无效(预期)'}")
    print()
    
    # 7. 列出用户
    print("7. 列出用户...")
    users = auth.list_users()
    print(f"   用户总数: {len(users)}")
    for user in users:
        print(f"   - {user.username} ({user.role})")
    print()
    
    # 8. 更新用户信息
    print("8. 更新用户信息...")
    result = auth.update_user("testuser", email="updated@example.com")
    print(f"   更新结果: {'成功' if result else '失败'}")
    user = auth.get_user("testuser")
    if user:
        print(f"   更新后邮箱: {user.email}")
    print()
    
    # 9. 删除用户
    print("9. 删除测试用户...")
    result = auth.delete_user("testuser")
    print(f"   删除结果: {'成功' if result else '失败'}")
    print()
    
    # 10. 测试禁止删除管理员
    print("10. 测试禁止删除管理员...")
    result = auth.delete_user("admin")
    print(f"   删除管理员结果: {'成功' if result else '失败(预期)'}")
    print()
    
    print("=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    test_auth()
