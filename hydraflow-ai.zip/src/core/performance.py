"""HydraFlow AI 性能监控与内存优化模块"""

import asyncio
import gc
import time
import psutil
import tracemalloc
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
from functools import wraps
from collections import defaultdict
import weakref

from src.core.config import get_settings

settings = get_settings()


@dataclass
class MemorySnapshot:
    """内存快照"""
    timestamp: float
    rss_mb: float
    vms_mb: float
    available_mb: float
    used_percent: float
    python_allocated_mb: float
    python_peak_mb: float


@dataclass
class PerformanceMetrics:
    """性能指标"""
    function_name: str
    calls: int
    total_time: float
    avg_time: float
    min_time: float
    max_time: float
    total_memory_delta: float


class MemoryProfiler:
    """内存分析器"""

    _instance: Optional["MemoryProfiler"] = None

    def __new__(cls) -> "MemoryProfiler":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._snapshots: list[MemorySnapshot] = []
        self._monitoring = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._process = psutil.Process()
        tracemalloc.start()

    def take_snapshot(self) -> MemorySnapshot:
        """拍摄内存快照"""
        memory_info = self._process.memory_info()
        virtual_memory = psutil.virtual_memory()

        current, peak = tracemalloc.get_traced_memory()

        snapshot = MemorySnapshot(
            timestamp=time.time(),
            rss_mb=memory_info.rss / 1024 / 1024,
            vms_mb=memory_info.vms / 1024 / 1024,
            available_mb=virtual_memory.available / 1024 / 1024,
            used_percent=virtual_memory.percent,
            python_allocated_mb=current / 1024 / 1024,
            python_peak_mb=peak / 1024 / 1024,
        )

        self._snapshots.append(snapshot)
        return snapshot

    async def start_monitoring(self, interval: float = 60.0) -> None:
        """开始监控"""
        if self._monitoring:
            return

        self._monitoring = True
        self._monitor_task = asyncio.create_task(self._monitor_loop(interval))

    async def _monitor_loop(self, interval: float) -> None:
        """监控循环"""
        while self._monitoring:
            try:
                self.take_snapshot()
                await asyncio.sleep(interval)
            except Exception:
                break

    async def stop_monitoring(self) -> None:
        """停止监控"""
        self._monitoring = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

    def get_snapshots(self, limit: Optional[int] = None) -> list[MemorySnapshot]:
        """获取快照"""
        if limit:
            return self._snapshots[-limit:]
        return self._snapshots.copy()

    def get_memory_trend(self) -> dict:
        """获取内存趋势"""
        if len(self._snapshots) < 2:
            return {"trend": "insufficient_data"}

        first = self._snapshots[0]
        last = self._snapshots[-1]

        rss_change = last.rss_mb - first.rss_mb
        python_change = last.python_allocated_mb - first.python_allocated_mb

        return {
            "duration_seconds": last.timestamp - first.timestamp,
            "rss_start_mb": first.rss_mb,
            "rss_end_mb": last.rss_mb,
            "rss_change_mb": rss_change,
            "python_start_mb": first.python_allocated_mb,
            "python_end_mb": last.python_allocated_mb,
            "python_change_mb": python_change,
            "avg_available_mb": sum(s.available_mb for s in self._snapshots) / len(self._snapshots),
        }

    def force_garbage_collection(self) -> dict:
        """强制垃圾回收"""
        before = self.take_snapshot()
        gc.collect()
        after = self.take_snapshot()

        return {
            "before_rss_mb": before.rss_mb,
            "after_rss_mb": after.rss_mb,
            "freed_mb": before.rss_mb - after.rss_mb,
            "before_python_mb": before.python_allocated_mb,
            "after_python_mb": after.python_allocated_mb,
            "python_freed_mb": before.python_allocated_mb - after.python_allocated_mb,
        }


class PerformanceMonitor:
    """性能监控器"""

    def __init__(self):
        self._metrics: dict[str, list[float]] = defaultdict(list)
        self._memory_deltas: dict[str, list[float]] = defaultdict(list)
        self._lock = asyncio.Lock()

    async def record_execution(
        self,
        function_name: str,
        duration: float,
        memory_delta: float = 0,
    ) -> None:
        """记录执行"""
        async with self._lock:
            self._metrics[function_name].append(duration)
            self._memory_deltas[function_name].append(memory_delta)

    def get_metrics(self, function_name: Optional[str] = None) -> dict[str, PerformanceMetrics]:
        """获取性能指标"""
        result = {}

        names = [function_name] if function_name else self._metrics.keys()

        for name in names:
            if name not in self._metrics:
                continue

            times = self._metrics[name]
            memory = self._memory_deltas.get(name, [0])

            result[name] = PerformanceMetrics(
                function_name=name,
                calls=len(times),
                total_time=sum(times),
                avg_time=sum(times) / len(times),
                min_time=min(times),
                max_time=max(times),
                total_memory_delta=sum(memory),
            )

        return result

    def get_slowest_functions(self, limit: int = 10) -> list[PerformanceMetrics]:
        """获取最慢函数"""
        metrics = self.get_metrics()
        sorted_metrics = sorted(
            metrics.values(),
            key=lambda m: m.total_time,
            reverse=True,
        )
        return sorted_metrics[:limit]

    def get_most_memory_intensive(self, limit: int = 10) -> list[PerformanceMetrics]:
        """获取内存占用最多的函数"""
        metrics = self.get_metrics()
        sorted_metrics = sorted(
            metrics.values(),
            key=lambda m: m.total_memory_delta,
            reverse=True,
        )
        return sorted_metrics[:limit]

    def clear(self) -> None:
        """清除所有指标"""
        self._metrics.clear()
        self._memory_deltas.clear()


def async_profile(memory_tracking: bool = False):
    """异步性能分析装饰器"""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            monitor = get_performance_monitor()
            profiler = get_memory_profiler()

            start_time = time.time()
            start_memory = 0

            if memory_tracking:
                snapshot = profiler.take_snapshot()
                start_memory = snapshot.python_allocated_mb

            try:
                result = await func(*args, **kwargs)
                return result
            finally:
                duration = time.time() - start_time
                memory_delta = 0

                if memory_tracking:
                    end_snapshot = profiler.take_snapshot()
                    memory_delta = end_snapshot.python_allocated_mb - start_memory

                await monitor.record_execution(
                    func.__name__,
                    duration,
                    memory_delta,
                )

        return wrapper
    return decorator


def sync_profile(memory_tracking: bool = False):
    """同步性能分析装饰器"""
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            monitor = get_performance_monitor()
            profiler = get_memory_profiler()

            start_time = time.time()
            start_memory = 0

            if memory_tracking:
                snapshot = profiler.take_snapshot()
                start_memory = snapshot.python_allocated_mb

            try:
                result = func(*args, **kwargs)
                return result
            finally:
                duration = time.time() - start_time
                memory_delta = 0

                if memory_tracking:
                    end_snapshot = profiler.take_snapshot()
                    memory_delta = end_snapshot.python_allocated_mb - start_memory

                asyncio.create_task(monitor.record_execution(
                    func.__name__,
                    duration,
                    memory_delta,
                ))

        return wrapper
    return decorator


class ObjectPool(Generic[T]):
    """对象池 - 减少对象创建开销"""

    def __init__(self, factory: Callable[[], T], max_size: int = 100):
        self._factory = factory
        self._max_size = max_size
        self._pool: list[T] = []
        self._lock = asyncio.Lock()

    async def acquire(self) -> T:
        """获取对象"""
        async with self._lock:
            if self._pool:
                return self._pool.pop()
            return self._factory()

    async def release(self, obj: T) -> None:
        """释放对象回池"""
        async with self._lock:
            if len(self._pool) < self._max_size:
                self._pool.append(obj)

    @asynccontextmanager
    async def use(self):
        """上下文管理器使用对象"""
        obj = await self.acquire()
        try:
            yield obj
        finally:
            await self.release(obj)


class WeakRefCache(Generic[T]):
    """弱引用缓存 - 自动清理无用对象"""

    def __init__(self, max_size: int = 1000):
        self._cache: dict[str, weakref.ref] = {}
        self._order: list[str] = []
        self._max_size = max_size
        self._lock = asyncio.Lock()

    def get(self, key: str) -> Optional[T]:
        """获取缓存值"""
        ref = self._cache.get(key)
        if ref:
            return ref()
        return None

    def set(self, key: str, value: T) -> None:
        """设置缓存值"""
        if key in self._cache:
            self._order.remove(key)
        elif len(self._cache) >= self._max_size:
            oldest = self._order.pop(0)
            if oldest in self._cache:
                del self._cache[oldest]

        self._cache[key] = weakref.ref(value)
        self._order.append(key)

    def clear(self) -> None:
        """清空缓存"""
        self._cache.clear()
        self._order.clear()


import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

logger = logging.getLogger("hydraflow.performance")

_performance_monitor_instance: Optional[PerformanceMonitor] = None
_memory_profiler_instance: Optional[MemoryProfiler] = None


def get_performance_monitor() -> PerformanceMonitor:
    """获取性能监控器单例"""
    global _performance_monitor_instance
    if _performance_monitor_instance is None:
        _performance_monitor_instance = PerformanceMonitor()
    return _performance_monitor_instance


def get_memory_profiler() -> MemoryProfiler:
    """获取内存分析器单例"""
    global _memory_profiler_instance
    if _memory_profiler_instance is None:
        _memory_profiler_instance = MemoryProfiler()
    return _memory_profiler_instance
