"""HydraFlow AI API 模块"""

from src.api.app import create_app

__all__ = ["create_app"]
