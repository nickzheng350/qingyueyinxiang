#!/usr/bin/env python3
"""技能引擎测试脚本"""

import sys
import json
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from src.skills.skill_manager import SkillManager
from src.skills.skill_engine import get_skill_engine


def test_skill_engine():
    """测试技能引擎"""
    print("=" * 60)
    print("技能引擎测试")
    print("=" * 60)
    print()
    
    # 1. 测试技能管理器
    print("1. 测试技能管理器...")
    skill_manager = SkillManager()
    
    # 列出已安装的技能
    skills = skill_manager.list_skills()
    print(f"   已安装技能数：{len(skills)}")
    
    if skills:
        for skill in skills:
            print(f"   - {skill.get('skill_id')}: {skill.get('name')}")
    print()
    
    # 2. 测试技能引擎
    print("2. 测试技能引擎...")
    engine = get_skill_engine()
    
    # 注册一个测试技能
    print("   注册测试技能...")
    engine.register_skill(
        skill_id="test_hello",
        skill_name="测试问候技能",
        skill_version="1.0.0",
        executor_type="dynamic",
        module_path=str(Path(__file__).parent / "skills" / "local" / "example_hello" / "executor.py"),
        config={"default_greeting": "你好", "enable_logging": True},
    )
    print("   ✓ 技能注册成功")
    print()
    
    # 3. 测试技能执行
    print("3. 测试技能执行...")
    
    # 异步执行
    import asyncio
    
    async def test_async():
        result = await engine.execute_skill("test_hello", name="张三")
        return result
    
    result = asyncio.run(test_async())
    
    print(f"   执行结果：{'成功' if result.success else '失败'}")
    print(f"   执行时间：{result.execution_time:.3f}秒")
    
    if result.success:
        print(f"   返回数据：{json.dumps(result.data, ensure_ascii=False, indent=2)}")
    else:
        print(f"   错误信息：{result.error}")
    print()
    
    # 4. 测试技能管理器执行
    print("4. 测试技能管理器执行（如果技能已安装）...")
    if skills:
        first_skill = skills[0]
        skill_id = first_skill.get('skill_id')
        print(f"   尝试执行技能：{skill_id}")
        result = skill_manager.execute_skill(skill_id, test_param="test")
        print(f"   执行结果：{json.dumps(result, ensure_ascii=False, indent=2)}")
    else:
        print("   跳过（没有已安装的技能）")
    print()
    
    # 5. 列出技能引擎中的技能
    print("5. 技能引擎中的技能:")
    engine_skills = engine.list_skills()
    for skill_info in engine_skills:
        print(f"   - {skill_info['skill_id']}: {skill_info['skill_name']} v{skill_info['skill_version']}")
    print()
    
    print("=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    test_skill_engine()
