#!/usr/bin/env python3
"""WebSocket 测试脚本"""

import sys
import asyncio
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.ws.manager import get_ws_manager
from src.task_engine.executor import get_task_executor, TaskType


async def test_websocket():
    """测试 WebSocket 管理器"""
    print("=" * 60)
    print("WebSocket 功能测试")
    print("=" * 60)
    print()
    
    # 1. 获取管理器
    print("1. 获取 WebSocket 管理器...")
    ws_manager = get_ws_manager()
    print("   ✓ WebSocket 管理器已准备")
    print()
    
    # 2. 获取任务执行器
    print("2. 获取任务执行器...")
    executor = get_task_executor()
    print("   ✓ 任务执行器已准备")
    print()
    
    # 3. 创建测试任务
    print("3. 创建测试任务...")
    task_id = await executor.submit_task(
        task_type=TaskType.IMAGE_GENERATION,
        prompt="测试图片生成",
        parameters={"width": 1024, "height": 768},
        model_id="sdxl_1.0"
    )
    print(f"   ✓ 任务创建成功: {task_id}")
    print()
    
    # 4. 模拟WebSocket订阅
    print("4. 模拟 WebSocket 订阅...")
    queue = await ws_manager.connect()
    await ws_manager.subscribe_to_task(task_id, queue)
    print("   ✓ 已订阅任务状态")
    print()
    
    # 5. 接收任务更新
    print("5. 接收任务更新（等待任务完成）...")
    update_count = 0
    max_updates = 12  # 包括初始状态和完成状态
    
    while update_count < max_updates:
        try:
            msg = await asyncio.wait_for(queue.get(), timeout=5.0)
            data = json.loads(msg)
            print(f"   更新 #{update_count + 1}:")
            print(f"      类型: {data.get('type')}")
            print(f"      任务ID: {data.get('task_id')}")
            print(f"      状态: {data.get('status')}")
            print(f"      进度: {data.get('progress')}%")
            print(f"      时间戳: {data.get('timestamp')}")
            update_count += 1
            print()
        except asyncio.TimeoutError:
            print("   ⚠️  超时，结束监听")
            break
        except Exception as e:
            print(f"   ❌ 错误: {e}")
            break
    
    # 6. 断开连接
    print("6. 断开连接...")
    await ws_manager.disconnect(queue)
    print("   ✓ 已断开连接")
    print()
    
    # 7. 验证任务完成
    print("7. 验证任务状态...")
    task_info = executor.get_task_info(task_id)
    print(f"   任务状态: {task_info.get('status')}")
    print(f"   任务进度: {task_info.get('progress')}%")
    print(f"   任务结果: {json.dumps(task_info.get('result'), ensure_ascii=False, indent=2)}")
    print()
    
    print("=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test_websocket())
